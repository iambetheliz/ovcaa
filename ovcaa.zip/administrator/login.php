<?php

session_start(); // Starting Session

if (isset($_POST['signin'])) {
    if (empty($_POST['uname']) || empty($_POST['upass'])) {
        $errMSG = "Fields cannot be empty! Try again<br><br>";
        header("Refresh: 2; url=/ovcaa/administrator");
    }
    else 
    {
        // Define $uname and $upass
        $uname=$_POST['uname'];
        $upass=$_POST['upass'];
        // Establishing Connection with Server by passing server_name, user_id and upass as a parameter
        $connection = mysql_connect("localhost", "root", "");
        // To protect MySQL injection for Security purpose
        $uname = stripslashes($uname);
        $upass = stripslashes($upass);
        $uname = mysql_real_escape_string($uname);
        $upass = mysql_real_escape_string($upass);
        // Selecting Database
        $db = mysql_select_db("ovcaa", $connection);
        // SQL query to fetch information of registerd users and finds user match.
        $query = mysql_query("select * from members where upass='$upass' AND uname='$uname'", $connection);
        $rows = mysql_num_rows($query);
        
        if ($rows == 1) {
            $_SESSION['login_admin']=$uname; // Initializing Session    
            $successMSG = "Successfully logged in!";     
            header("Refresh:2; url=dashboard.php");
            
        } 
        else {
            $errMSG = "Invalid credentials. Try again";
            header("Refresh: 2; url=/ovcaa/administrator");
        }
    
    mysql_close($connection); // Closing Connection
    }
}
?>