
== Product Details ==

*   name           Simple Responsive Slideshow
*   version        2.5
*   description    Responsive Joomla! Slider based on Flexslider 1.8 by Woothemes
*   demo           http://extensions.favthemes.com/simple-responsive-slideshow
*   author         FavThemes
*   author URL     http://www.favthemes.com
*   copyright      Copyright (C) 2012-2016 FavThemes.com. All Rights Reserved.
*   license        Licensed under GNU/GPLv3, see http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

*   Simple Responsive Slideshow is a free responsive Joomla! module that let's you upload up to 10 images to create a slideshow and customize each slide.

== Documentation ==

*   http://extensions.favthemes.com/simple-responsive-slideshow#documentation

== Compatibility ==

*   Joomla! 3.x.
*   Bootstrap version: Joomla!'s 3.x. default version
*   jQuery version: Joomla!'s 3.x. default version

== Support ==

*   For any support requests, write us an email at support@favthemes.com
