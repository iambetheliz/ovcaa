<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 0.2b
 */

//
// Database `ovcaa`
//

// `ovcaa`.`material`
$material = array(
  array('title' => '0','description' => '','filename' => 'best-nature-desktop-hd-wallpaper.jpg','filesize' => '417','location' => '','url' => '','uploaded_by' => '','date_created' => '0000-00-00 00:00:00.000000','date_updated' => '0000-00-00 00:00:00.000000','category_id' => '0'),
  array('title' => '0','description' => '','filename' => 'picture-nature-18.jpg','filesize' => '188','location' => '','url' => '','uploaded_by' => '','date_created' => '0000-00-00 00:00:00.000000','date_updated' => '0000-00-00 00:00:00.000000','category_id' => '0')
);
