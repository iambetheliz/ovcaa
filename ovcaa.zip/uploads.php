<?php
include('User.php'); // Includes Login Script

session_start();

if(!isset($_SESSION['token'])){
header("location: 403-error.html");
}
?>
<?php

    require_once 'Material.php';
    
    if(isset($_GET['delete_id']))
 {
  // select image from db to delete
  $stmt_select = $DB_con->prepare('SELECT material.filename, category.category_id, category.cat_name FROM material JOIN 
    category ON category.category_id = material.category_id WHERE id =:id');
  $stmt_select->execute(array(':id'=>$_GET['delete_id']));
  $fileRow=$stmt_select->fetch(PDO::FETCH_ASSOC);
  unlink("../administrator/uploads/".$fileRow['filename']);
  
  // it will delete an actual record from db
  $stmt_delete = $DB_con->prepare('DELETE FROM material WHERE id =:id');
  $stmt_delete->bindParam(':id',$_GET['delete_id']);
  $stmt_delete->execute();
  
  header("Location: uploads.php");
 }
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
<title>UP Open University</title>
<script src="https://apis.google.com/js/platform.js" async defer></script>
<link href="../assets/css/bootstrap.css" rel="stylesheet">
<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/bootstrap-tdeme.css" rel="stylesheet">
<link href="../assets/css/font-awesome.min.css" rel="stylesheet">
<style type="text/css">
            a[href="/absolute/path/to/index/root/parent/"] {display: none;}
        </style>
</head>
<body>
<?php include('header.php'); ?>
<div class="wrap">
<div class="container">
<?php
    
    $stmt = $DB_con->prepare('SELECT *, category.category_id, category.cat_name FROM material JOIN 
    category ON category.category_id = material.category_id ORDER BY date_created DESC');
    $stmt->execute();    
    $count = $stmt->rowCount();?>

<div class="row">
    <div class="col-sm-4">
        <h2><strong>Uploads <font color="#7b1113">(<?php echo $count; ?>)</font></strong></h2>
    </div>
    <div class="col-sm-4 right"><br>
        <div class="input-group">
            <div class="input-group-btn search-panel">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                      <span id="search_concept">Filter by</span> <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu" role="menu">
                      <li><a href="#contains">Contains</a></li>
                      <li><a href="#its_equal">It's equal</a></li>
                      <li><a href="#greather_than">Greather than ></a></li>
                      <li><a href="#less_than">Less than < </a></li>
                      <li class="divider"></li>
                      <li><a href="#all">Anything</a></li>
                    </ul>
            </div>
                <input type="hidden" name="search_param" value="all" id="search_param">
                <input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Search for terms..">
                <span class="input-group-btn">
                    <button class="btn btn-default" type="button"><span class="glyphicon glyphicon-search"></span></button>
                </span>
        </div>
    </div>
</div>
 <script>
function myFunction() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}
</script>
 <?php 
    include 'function.php';
    include 'pagination.php';
 ?>
    <?php
  if(isset($errMSG)){
      ?>
            <div class="alert alert-danger">
              <span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
            </div><br>
            <?php
  }?>

        </div>
</div>

    <footer class="footer">
    <div class="container-fluid">
        <p>&copy; UP Open University 2017</p>
    </div>
    </footer>

<script src="assets/js/bootstrap.js"></script>
</body>
</html>